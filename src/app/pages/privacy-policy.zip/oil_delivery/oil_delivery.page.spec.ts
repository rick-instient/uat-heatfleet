import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OilDeliveryPage } from './oil_delivery.page';

describe('OilDeliveryPage', () => {
  let component: OilDeliveryPage;
  let fixture: ComponentFixture<OilDeliveryPage>;

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
