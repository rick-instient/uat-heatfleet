import { async, ComponentFixture, TestBed } from '@angular/core/testing';


import { TownSpecificPage } from './town-profile.page';

describe('TownSpecificPage', () => {
  let component: TownSpecificPage;
  let fixture: ComponentFixture<TownSpecificPage>;


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
