import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeatingOilPage } from './heating_oil.page';

describe('HeatingOilPage', () => {
  let component: HeatingOilPage;
  let fixture: ComponentFixture<HeatingOilPage>;

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
