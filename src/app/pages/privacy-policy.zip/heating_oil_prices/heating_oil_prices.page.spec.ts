import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HeatingOilPricesPage } from './heating_oil_prices.page';

describe('HeatingOilPricesPage', () => {
  let component: HeatingOilPricesPage;
  let fixture: ComponentFixture<HeatingOilPricesPage>;


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
